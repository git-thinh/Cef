﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CefSharp.WinForms.Internals
{
    internal static class NativeMethods
    {
        public const int WM_MOVE = 0x3;
        public const int WM_MOVING = 0x216;
        public const int WM_ACTIVATE = 0x6;
    }
}
